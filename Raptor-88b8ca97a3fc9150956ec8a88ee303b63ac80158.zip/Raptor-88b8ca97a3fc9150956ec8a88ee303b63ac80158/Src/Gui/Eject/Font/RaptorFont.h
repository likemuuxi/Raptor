/**
 *
 * Copyright (C) 2024 凉州刺史. All rights reserved.
 *
 * This file is part of Raptor.
 *
 * $RAPTOR_BEGIN_LICENSE$
 *
 * GNU General Public License Usage
 * Alternatively, this file may be used under the terms of the GNU
 * General Public License version 3.0 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.  Please review the following information to
 * ensure the GNU General Public License version 3.0 requirements will be
 * met: http://www.gnu.org/copyleft/gpl.html.
 *
 * $RAPTOR_END_LICENSE$
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef RAPTORFONT_H
#define RAPTORFONT_H

#include <QFontDatabase>
#include <QStringListModel>

#include "../Toast/RaptorToast.h"
#include "../../../Component/Eject/RaptorEject.h"
#include "../../../Common/RaptorDefine.h"
#include "../../../Util/RaptorUtil.h"

QT_BEGIN_NAMESPACE

namespace Ui
{
    class RaptorFont;
}

QT_END_NAMESPACE

class RaptorFont Q_DECL_FINAL : public RaptorEject
{
    Q_OBJECT

public:
    explicit RaptorFont(QWidget* qParent = Q_NULLPTR);

    ~RaptorFont() Q_DECL_OVERRIDE;

    bool eventFilter(QObject* qObject, QEvent* qEvent) Q_DECL_OVERRIDE;

    QString invokeEject();

private:
    void invokeInstanceInit() Q_DECL_OVERRIDE;

    void invokeUiInit() Q_DECL_OVERRIDE;

    void invokeSlotInit() Q_DECL_OVERRIDE;

private Q_SLOTS:
    Q_SLOT void onCloseClicked();

    Q_SLOT void onItemViewClicked(const QModelIndex& qIndex);

    Q_SLOT void onItemViewDoubleClicked(const QModelIndex& qIndex);

    Q_SLOT void onOKClicked();

private:
    Ui::RaptorFont* _Ui = Q_NULLPTR;
    QStringListModel* _ItemViewModel = Q_NULLPTR;
    QString _FontName;
};

#endif // RAPTORFONT_H